﻿Font Terms and Conditions
- Fonts are free for personal and non-profit projects.
- Personal works displayed online using the fonts must provide the font source.
- A commercial license is needed for any work made to generate income.

Commercial License
- The license is granted for lifetime, for any kind of project, worldwide, for one individual or company.
- The license is non-exclusive, non-transferable and usable with no royalties.
- The license can be purchased with a $20 payment on PayPal to levi@loremipsum.ro

Notes
- The process doesn't require a PayPal account and the payment receipt proves you a legible user of the font.
- After the payment the copyright free font is sent to your email address.
- For invoices or other forms of license please write to levi@loremipsum.ro

Thank you, 
Levi
